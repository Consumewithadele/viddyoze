module ApplicationHelper

end
