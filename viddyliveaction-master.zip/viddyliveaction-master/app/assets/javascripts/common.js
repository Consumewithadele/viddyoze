$('.ui.checkbox').checkbox();
$('.ui.dropdown').dropdown();

$(document).ready(function() {
  $('.sidebar').height($(document).height() - 201);
  
  $('.account-trigger').click(function() {
    $(this).toggleClass('selected');
    $('.account-sidebar').toggleClass('active');
    $('.account-overlay').toggleClass('active')
  })
  
  // Progress indicator JS
  $(function(){
      $('.progress-indicator').animate({'width':'100%'},{
        duration: 5000,
        step: function(now,fx){ 
          $('.progress-value').text(Math.floor(now) + '%');
        },
        // This is when the rendering completes
        complete: function() {
          $(this).addClass('finished');
          $('.render.box .top').addClass('finished');
          $('.render-meta').addClass('finished');
          $('.render-title').text('Rendering completed')
        }
      });
  });
  
})
