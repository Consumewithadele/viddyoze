class WelcomeController < ApplicationController
  def index
  end
  def edit
  end
  def create
  end
end
