class LoginController < ApplicationController
  layout 'login'
  
  def login
  end

  def register
  end

  def forgot
  end
end
